package com.photerest.ai

import android.content.*
import android.net.Uri
import android.os.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object ModelSpec {
    const val HUB = "com.photerest.aihub"
    const val FILE = "embeddinggemma-2-740m.litertlm"
    const val BYTES = 484_622_336L
    const val SHA = "e7a8a2204b91e0f96e92960e84a09a89212e1633dcb7575a9bf3378b4df77f4c"
    const val REVISION = "86b903a293f96d042bb92e1b7af333d94114458f"
    const val URL = "https://huggingface.co/litert-community/embeddinggemma-2-740m-litert-lm/resolve/$REVISION/$FILE?download=true"
    fun supported() = Build.VERSION.SDK_INT >= 31 && "arm64-v8a" in Build.SUPPORTED_ABIS
    fun installed(context: Context) = runCatching { context.packageManager.getApplicationInfo(HUB, 0) }.isSuccess
    fun openCenter(context: Context) {
        check(installed(context)) { "请先安装 Photerest AI Hub 模型中心" }
        context.startActivity(Intent().setComponent(ComponentName(HUB, "$HUB.MainActivity")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun importFromAlpha(context: Context, uri: Uri) {
        check(installed(context)) { "请先安装 Photerest AI Hub 模型中心" }
        context.startActivity(Intent(Intent.ACTION_SEND).setComponent(ComponentName(HUB, "$HUB.ImportActivity"))
            .setType("application/octet-stream").putExtra(Intent.EXTRA_STREAM, uri)
            .apply { clipData = ClipData.newRawUri("已有本地模型", uri) }
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

data class HubResult(val metadata: Bundle, val vector: FloatArray)

/** No model or inference library is stored in this client. */
class AiClient(context: Context) : AutoCloseable {
    private val app = context.applicationContext
    private val connectionMutex = Mutex()
    @Volatile private var remote: IAiHub? = null
    @Volatile private var connection: ServiceConnection? = null
    private suspend fun service(): IAiHub = withContext(Dispatchers.IO) {
        connectionMutex.withLock {
            remote?.takeIf { it.asBinder().isBinderAlive }?.let { return@withLock it }
            check(ModelSpec.supported()) { "需要 Android 12 及以上的 ARM64 手机" }
            check(ModelSpec.installed(app)) { "请先安装 Photerest AI Hub 模型中心" }
            close()
            withTimeout(15_000) {
                suspendCancellableCoroutine { continuation ->
                    val link = object : ServiceConnection {
                        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                            if (connection !== this) return
                            val api = IAiHub.Stub.asInterface(binder)
                            remote = api
                            if (continuation.isActive) continuation.resume(api)
                        }
                        override fun onServiceDisconnected(name: ComponentName) { if (connection === this) remote = null }
                        override fun onBindingDied(name: ComponentName) { if (connection === this) remote = null }
                        override fun onNullBinding(name: ComponentName) {
                            if (continuation.isActive) continuation.resumeWithException(IllegalStateException("模型中心拒绝连接"))
                        }
                    }
                    connection = link
                    continuation.invokeOnCancellation { if (connection === link) close() }
                    try {
                        if (!app.bindService(Intent().setComponent(ComponentName(ModelSpec.HUB, "${ModelSpec.HUB}.AiService")), link, Context.BIND_AUTO_CREATE)) {
                            close()
                            if (continuation.isActive) continuation.resumeWithException(IllegalStateException("无法连接模型中心"))
                        }
                    } catch (failure: Exception) {
                        close()
                        if (continuation.isActive) continuation.resumeWithException(failure)
                    }
                }
            }
        }
    }
    suspend fun status(): Bundle = withContext(Dispatchers.IO) {
        service().getStatus().also { check(it.getInt("protocol") == 1) { "模型中心协议不兼容，请更新安装包" } }
    }
    private suspend fun request(timeout: Long = 180_000, operation: (IAiHub, String, IAiCallback) -> Unit): HubResult = withContext(Dispatchers.IO) {
        val api = service()
        withTimeout(timeout) {
            suspendCancellableCoroutine { continuation ->
                val id = UUID.randomUUID().toString()
                val delivered = AtomicBoolean()
                val callback = object : IAiCallback.Stub() {
                    override fun onResult(requestId: String, metadata: Bundle, vector: FloatArray) {
                        if (delivered.compareAndSet(false, true) && continuation.isActive) continuation.resume(HubResult(metadata, vector))
                    }
                    override fun onError(requestId: String, message: String) {
                        if (delivered.compareAndSet(false, true) && continuation.isActive) continuation.resumeWithException(IllegalStateException(message))
                    }
                }
                val death = IBinder.DeathRecipient {
                    remote = null
                    if (delivered.compareAndSet(false, true) && continuation.isActive) continuation.resumeWithException(IllegalStateException("模型中心已中断，请重新连接"))
                }
                try {
                    api.asBinder().linkToDeath(death, 0)
                    continuation.invokeOnCancellation {
                        runCatching { api.cancel(id) }
                        runCatching { api.asBinder().unlinkToDeath(death, 0) }
                    }
                    operation(api, id, object : IAiCallback.Stub() {
                        override fun onResult(requestId: String, metadata: Bundle, vector: FloatArray) {
                            runCatching { api.asBinder().unlinkToDeath(death, 0) }
                            callback.onResult(requestId, metadata, vector)
                        }
                        override fun onError(requestId: String, message: String) {
                            runCatching { api.asBinder().unlinkToDeath(death, 0) }
                            callback.onError(requestId, message)
                        }
                    })
                } catch (failure: Exception) {
                    runCatching { api.asBinder().unlinkToDeath(death, 0) }
                    if (delivered.compareAndSet(false, true) && continuation.isActive) continuation.resumeWithException(failure)
                }
            }
        }
    }
    suspend fun load() = request { api, id, cb -> api.load(id, cb) }
    suspend fun text(text: String) = request { api, id, cb -> api.embedText(id, text, cb) }.also { valid(it.vector) }
    suspend fun image(tga: ByteArray): HubResult = withContext(Dispatchers.IO) {
        val temp = File.createTempFile("hub-input-", ".tga", app.cacheDir)
        try {
            temp.writeBytes(tga)
            ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                request { api, id, cb -> api.embedImage(id, fd, cb) }.also { valid(it.vector) }
            }
        } finally { temp.delete() }
    }
    suspend fun download() = request(1_800_000) { api, id, cb -> api.downloadModel(id, cb) }
    suspend fun importModel(fd: ParcelFileDescriptor) = request(1_800_000) { api, id, cb -> api.importModel(id, fd, cb) }
    suspend fun deleteModel() = request { api, id, cb -> api.deleteModel(id, cb) }
    private fun valid(vector: FloatArray) { check(vector.size == 768 && vector.all { it.isFinite() }) { "模型返回无效向量" } }
    override fun close() {
        remote = null
        val link = connection
        connection = null
        if (link != null) runCatching { app.unbindService(link) }
    }
}
