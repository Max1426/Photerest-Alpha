package com.photerest.ai

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.max


object OriginalImageInput {
        /** Gallery's ImageUtils.encodeTga: UniversalEmbedder accepts TGA bytes. */
        fun encodeTga(bitmap: Bitmap): ByteArray {
            val width = bitmap.width
            val height = bitmap.height
            val pixels = IntArray(width * height)
            if (Build.VERSION.SDK_INT >= 26 && bitmap.config == Bitmap.Config.HARDWARE) {
                val copy = checkNotNull(bitmap.copy(Bitmap.Config.ARGB_8888, false))
                try {
                    copy.getPixels(pixels, 0, width, 0, 0, width, height)
                } finally {
                    copy.recycle()
                }
            } else {
                bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
            }
            val tga = ByteArray(20 + width * height * 4)
            val buffer = ByteBuffer.wrap(tga).order(ByteOrder.LITTLE_ENDIAN)
            tga[0] = 2
            tga[2] = 2
            tga[12] = (width and 0xFF).toByte()
            tga[13] = ((width shr 8) and 0xFF).toByte()
            tga[14] = (height and 0xFF).toByte()
            tga[15] = ((height shr 8) and 0xFF).toByte()
            tga[16] = 32
            tga[17] = 0x28
            buffer.position(20)
            buffer.asIntBuffer().put(pixels)
            return tga
        }

        /** Decodes a MediaStore photo into a TGA suitable for UniversalEmbedder. */
        fun loadTga(context: Context, photo: InputPhoto): ByteArray {
            val bitmap = checkNotNull(
                runCatching {
                    context.contentResolver.openInputStream(Uri.parse(photo.uri))?.use {
                        BitmapFactory.decodeStream(it)
                    }
                }.getOrNull()
            ) { "无法读取照片：${photo.name}" }
            val longest = max(bitmap.width, bitmap.height)
            val scaled = if (longest > 1024) {
                val ratio = 1024f / longest
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * ratio).toInt().coerceAtLeast(1),
                    (bitmap.height * ratio).toInt().coerceAtLeast(1),
                    true
                ).also { bitmap.recycle() }
            } else {
                bitmap
            }
            return try {
                encodeTga(scaled)
            } finally {
                scaled.recycle()
            }
        }
}
data class InputPhoto(val uri: String, val name: String)
