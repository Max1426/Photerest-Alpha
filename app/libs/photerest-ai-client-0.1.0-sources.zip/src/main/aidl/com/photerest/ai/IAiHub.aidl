package com.photerest.ai;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import com.photerest.ai.IAiCallback;
interface IAiHub {
 Bundle getStatus();
 void load(String requestId, IAiCallback callback);
 void embedText(String requestId, String text, IAiCallback callback);
 void embedImage(String requestId, in ParcelFileDescriptor input, IAiCallback callback);
 void cancel(String requestId);
 void downloadModel(String requestId, IAiCallback callback);
 void importModel(String requestId, in ParcelFileDescriptor input, IAiCallback callback);
 void deleteModel(String requestId, IAiCallback callback);
}
