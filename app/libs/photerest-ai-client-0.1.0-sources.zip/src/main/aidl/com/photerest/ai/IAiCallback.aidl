package com.photerest.ai;
import android.os.Bundle;
oneway interface IAiCallback {
 void onResult(String requestId, in Bundle metadata, in float[] vector);
 void onError(String requestId, String message);
}
