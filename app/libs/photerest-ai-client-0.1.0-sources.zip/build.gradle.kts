plugins { id("com.android.library"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.photerest.ai"
 compileSdk = 35
 defaultConfig { minSdk = 26 }
 buildFeatures { aidl = true }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0") }
